# Las Aventuras de Lía — prototipo v1

Prototipo jugable, táctil y sin dependencias para practicar la tabla del 4 dentro de una aventura infantil.

## Cómo jugar

1. Abre `index.html` con doble clic.
2. Pulsa **¡Vamos!** y sigue las indicaciones de Nubo.

Funciona sin servidor y sin conexión a internet en navegadores modernos. Si el navegador limita `localStorage` al abrir archivos locales, puedes iniciar un servidor opcional desde esta carpeta:

```bash
python3 -m http.server 8000
```

Después abre `http://localhost:8000`.

## Progreso guardado

El juego guarda en el navegador:

- escena actual;
- aciertos, errores y ayudas de `4×2`, `4×3` y `4×6`.

El botón **↻ Reiniciar** borra esos datos y vuelve al inicio.

## Estructura

- `index.html`: entrada de la aplicación.
- `css/game.css`: diseño responsive, animaciones y componentes visuales.
- `js/progreso.js`: lectura y escritura segura de `localStorage`.
- `js/sonidos.js`: efectos musicales sintetizados con Web Audio y control de sonido.
- `js/escenas.js`: contenido de las escenas jugables actuales.
- `js/game.js`: navegación, respuestas y eventos del juego.

No se usan frameworks, backend, fuentes ni recursos externos. Los personajes están incluidos localmente en `assets/personajes/` y el arte del mundo en `assets/reino-cuadrado/`.
