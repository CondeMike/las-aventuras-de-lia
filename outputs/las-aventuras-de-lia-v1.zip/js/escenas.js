(function () {
  "use strict";

  function marco(contenido, clase) {
    return '<section class="escena ' + (clase || "") + '">' +
      '<div class="particulas" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></div>' +
      '<div class="barra"><span class="insignia">✨ Las Aventuras de Lía</span><span class="controles">' +
      '<button class="sonido" data-accion="sonido" aria-label="Activar o silenciar sonidos">🔊</button>' +
      '<button class="reiniciar" data-accion="reiniciar" aria-label="Empezar de nuevo">↻ Reiniciar</button></span></div>' +
      contenido + '</section>';
  }

  const escenas = {
    1: function () {
      return marco(
        '<h1 class="titulo">Las Aventuras de Lía</h1>' +
        '<p class="subtitulo">El misterio de las cuatro torres</p>' +
        '<div class="personajes" aria-label="Lía y Nubo">' +
          '<div class="personaje personaje--lia"><img class="lia" src="assets/personajes/lia-v4.png" alt="Lía, la joven exploradora"><span>Lía</span></div>' +
          '<div class="personaje personaje--nubo"><img class="nubo" src="assets/personajes/nubo-v2.png" alt="Nubo, pequeño zorro dragón blanco y azul"><span>Nubo</span></div>' +
        '</div>' +
        '<div class="pergamino"><strong>¡Lía!</strong> Las cuatro torres están perdiendo su luz. ¿Me ayudas a recuperar sus cristales?</div>' +
        '<button class="boton boton--oro" data-accion="ir" data-escena="2">¡Vamos!</button>'
      , "escena--inicio");
    },
    2: function () {
      return marco(
        '<h1 class="titulo">Reino Cuadrado</h1>' +
        '<div class="pergamino pergamino--mapa"><strong>Debemos recuperar 3 cristales de energía</strong><br>para volver a encender las cuatro torres.</div>' +
        '<div class="cristales" aria-label="Tres cristales por recuperar"><span>◇</span><span>◇</span><span>◇</span></div>' +
        '<div class="mapa-ruta">' +
          '<span class="ruta-punto ruta-punto--1" aria-hidden="true"></span>' +
          '<span class="ruta-punto ruta-punto--2" aria-hidden="true"></span>' +
          '<span class="ruta-punto ruta-punto--3" aria-hidden="true"></span>' +
          '<button class="torre torre--activa" data-accion="ir" data-escena="3" aria-label="Explorar el jardín de la primera torre"><span class="portal">✦</span><small>Explorar<br>primera torre</small></button>' +
        '</div>' +
        '<div class="placa-mundo">Reino Cuadrado <small>Tabla del 4</small></div>'
      , "escena--mapa");
    },
    3: function () {
      return marco(
        '<h1 class="titulo">El jardín encantado</h1>' +
        '<p class="subtitulo">Hay 4 jardines con 2 flores en cada uno. ¿Cuántas flores hay?</p>' +
        '<div class="grupos grupos--cuatro" id="gruposFlores" aria-label="Cuatro grupos de dos flores">' +
          '<div class="grupo"><span class="elemento">🌸</span><span class="elemento">🌼</span></div>' +
          '<div class="grupo"><span class="elemento">🌷</span><span class="elemento">🌺</span></div>' +
          '<div class="grupo"><span class="elemento">🌻</span><span class="elemento">🌸</span></div>' +
          '<div class="grupo"><span class="elemento">🌼</span><span class="elemento">🌺</span></div>' +
        '</div>' +
        '<div class="opciones" aria-label="Elige una respuesta">' +
          '<button class="opcion" data-accion="responder-visual" data-valor="6">6</button>' +
          '<button class="opcion" data-accion="responder-visual" data-valor="8">8</button>' +
          '<button class="opcion" data-accion="responder-visual" data-valor="10">10</button>' +
        '</div>' +
        '<div class="mensaje" id="mensajeReto" role="status">Nubo: “Son 2 flores, cuatro veces. Cuenta conmigo.”</div>' +
        '<div id="continuarReto"></div>'
      , "escena--jardin");
    },
    4: function () {
      return marco(
        '<h1 class="titulo">La puerta de piedra</h1>' +
        '<p class="subtitulo">La puerta solo se abre con la respuesta correcta.</p>' +
        '<div class="puerta"><span class="cristal-puerta" aria-hidden="true">♦</span><div class="operacion">4 × 3 = ?</div></div>' +
        '<div class="opciones" aria-label="Elige una respuesta">' +
          '<button class="opcion" data-accion="responder-puerta" data-valor="8">8</button>' +
          '<button class="opcion" data-accion="responder-puerta" data-valor="12">12</button>' +
          '<button class="opcion" data-accion="responder-puerta" data-valor="16">16</button>' +
        '</div>' +
        '<div class="mensaje" id="mensajePuerta" role="status">Escucha cómo la puerta retumba…</div>'
      , "escena--puerta");
    },
    5: function () {
      return marco(
        '<h1 class="titulo">Nubo te ayuda</h1>' +
        '<img class="nubo nubo--ayuda" src="assets/personajes/nubo-v2.png" alt="Nubo sonriendo para ayudar a Lía">' +
        '<div class="pergamino"><strong>No pasa nada, Lía. Miremos juntos.</strong></div>' +
        '<div class="filas" aria-label="Tres grupos de cuatro puntos">' +
          '<div class="fila"><i>♦</i><i>♦</i><i>♦</i><i>♦</i></div><div class="fila"><i>♦</i><i>♦</i><i>♦</i><i>♦</i></div><div class="fila"><i>♦</i><i>♦</i><i>♦</i><i>♦</i></div>' +
        '</div>' +
        '<div class="explicacion"><span>4 + 4 + 4 = 12</span><span>4 × 3 = 12</span></div>' +
        '<button class="boton boton--oro" data-accion="ir" data-escena="4">Volver a intentarlo</button>'
      , "ayuda");
    },
    6: function () {
      return marco(
        '<h1 class="titulo">Las torres de los pajaritos</h1>' +
        '<div class="pergamino pergamino--reto"><strong>Hay 4 torres y en cada torre viven 6 pajaritos.</strong><br>¿Cuántos pajaritos hay en total?</div>' +
        '<div class="torres-pajaros" aria-label="Cuatro torres, cada una con seis pajaritos">' +
          '<div class="torre-pajaros"><span>🐦🐦🐦</span><span>🐦🐦🐦</span><b>🏰</b></div>' +
          '<div class="torre-pajaros"><span>🐦🐦🐦</span><span>🐦🐦🐦</span><b>🏰</b></div>' +
          '<div class="torre-pajaros"><span>🐦🐦🐦</span><span>🐦🐦🐦</span><b>🏰</b></div>' +
          '<div class="torre-pajaros"><span>🐦🐦🐦</span><span>🐦🐦🐦</span><b>🏰</b></div>' +
        '</div>' +
        '<div class="opciones" aria-label="Elige una respuesta">' +
          '<button class="opcion" data-accion="responder-historia" data-valor="20">20</button>' +
          '<button class="opcion" data-accion="responder-historia" data-valor="24">24</button>' +
          '<button class="opcion" data-accion="responder-historia" data-valor="28">28</button>' +
        '</div>' +
        '<div class="mensaje" id="mensajeHistoria" role="status">Nubo: “Mira las cuatro torres y piensa con calma.”</div>' +
        '<div id="continuarHistoria"></div>'
      , "escena--pajaritos");
    }
  };

  window.Escenas = escenas;
})();
