(function () {
  "use strict";

  const CLAVE = "aventurasDeLia.v1";
  const base = {
    escenaActual: 1,
    operaciones: {
      "4x2": { aciertos: 0, errores: 0, ayudas: 0 },
      "4x3": { aciertos: 0, errores: 0, ayudas: 0 },
      "4x6": { aciertos: 0, errores: 0, ayudas: 0 }
    }
  };

  function copiarBase() {
    return JSON.parse(JSON.stringify(base));
  }

  function cargar() {
    try {
      const guardado = JSON.parse(localStorage.getItem(CLAVE));
      if (!guardado || typeof guardado !== "object") return copiarBase();
      const limpio = copiarBase();
      limpio.escenaActual = Math.min(6, Math.max(1, Number(guardado.escenaActual) || 1));
      Object.keys(limpio.operaciones).forEach(function (op) {
        Object.keys(limpio.operaciones[op]).forEach(function (metrica) {
          const operacionGuardada = guardado.operaciones && (guardado.operaciones[op] || (op === "4x2" && guardado.operaciones["2x4"]));
          const valor = operacionGuardada && operacionGuardada[metrica];
          limpio.operaciones[op][metrica] = Math.max(0, Number(valor) || 0);
        });
      });
      return limpio;
    } catch (error) {
      return copiarBase();
    }
  }

  let datos = cargar();

  function guardar() {
    try { localStorage.setItem(CLAVE, JSON.stringify(datos)); } catch (error) { /* El juego sigue sin persistencia. */ }
  }

  window.Progreso = {
    obtener: function () { return datos; },
    irAEscena: function (numero) { datos.escenaActual = numero; guardar(); },
    sumar: function (operacion, metrica) {
      if (!datos.operaciones[operacion]) datos.operaciones[operacion] = { aciertos: 0, errores: 0, ayudas: 0 };
      datos.operaciones[operacion][metrica] += 1;
      guardar();
    },
    reiniciar: function () { datos = copiarBase(); guardar(); }
  };
})();
