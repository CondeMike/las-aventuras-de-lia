(function () {
  "use strict";

  const raiz = document.getElementById("juego");
  let bloqueado = false;

  function celebrarOperacion(operacion, texto, conCristal) {
    const capa = document.createElement("div");
    capa.className = "celebracion-operacion" + (conCristal ? " celebracion-operacion--cristal" : "");
    capa.setAttribute("role", "status");
    capa.innerHTML =
      '<div class="rayos-logro" aria-hidden="true"></div>' +
      (conCristal ? '<div class="cristal-magico" aria-hidden="true"><span class="gema">◆</span><i></i><i></i><i></i><i></i><i></i><i></i></div>' : '') +
      '<div class="ecuacion-impacto">' + operacion + '</div>' +
      '<div class="texto-logro">' + texto + '</div>';
    raiz.querySelector(".escena").appendChild(capa);
    window.setTimeout(function () { capa.classList.add("celebracion-operacion--sale"); }, conCristal ? 1800 : 1200);
    window.setTimeout(function () { capa.remove(); }, conCristal ? 2350 : 1700);
  }

  function mostrar(numero) {
    bloqueado = false;
    Progreso.irAEscena(numero);
    raiz.innerHTML = Escenas[numero]();
    raiz.querySelector(".sonido").textContent = Sonidos.estaActivo() ? "🔊" : "🔇";
    window.scrollTo(0, 0);
    const titulo = raiz.querySelector("h1");
    if (titulo) { titulo.setAttribute("tabindex", "-1"); titulo.focus({ preventScroll: true }); }
  }

  function responderVisual(valor) {
    if (bloqueado) return;
    const mensaje = document.getElementById("mensajeReto");
    if (valor !== 8) {
      Sonidos.reproducir("casi");
      Progreso.sumar("4x2", "errores");
      mensaje.textContent = "Nubo: “Casi. Cuenta 2 flores en cada uno de los 4 jardines.”";
      return;
    }
    bloqueado = true;
    Sonidos.reproducir("acierto");
    Progreso.sumar("4x2", "aciertos");
    celebrarOperacion("4 × 2 = 8", "¡Hiciste florecer el camino!", false);
    document.getElementById("gruposFlores").classList.add("brilla");
    mensaje.className = "mensaje mensaje--bien";
    mensaje.innerHTML = "¡Las flores iluminan el camino! &nbsp; <strong>2 + 2 + 2 + 2 = 8 &nbsp;→&nbsp; 4 × 2 = 8</strong>";
    document.getElementById("continuarReto").innerHTML = '<button class="boton boton--oro" data-accion="ir" data-escena="4">Seguir el camino</button>';
  }

  function responderPuerta(valor) {
    if (bloqueado) return;
    if (valor !== 12) {
      bloqueado = true;
      Sonidos.reproducir("casi");
      Progreso.sumar("4x3", "errores");
      Progreso.sumar("4x3", "ayudas");
      const mensaje = document.getElementById("mensajePuerta");
      mensaje.textContent = "Nubo: “No pasa nada, Lía. Miremos juntos.”";
      window.setTimeout(function () { Sonidos.reproducir("ayuda"); mostrar(5); }, 900);
      return;
    }
    bloqueado = true;
    Sonidos.reproducir("puerta");
    window.setTimeout(function () { Sonidos.reproducir("poder"); }, 420);
    Progreso.sumar("4x3", "aciertos");
    const puerta = raiz.querySelector(".puerta");
    puerta.classList.add("puerta--abierta");
    const mensaje = document.getElementById("mensajePuerta");
    mensaje.className = "mensaje mensaje--bien";
    mensaje.innerHTML = "La puerta se abre y aparece el primer cristal. <strong>4 × 3 = 12</strong> &nbsp; 💎";
    celebrarOperacion("4 × 3 = 12", "¡Primer cristal recuperado!", true);
    raiz.querySelector(".opciones").remove();
    const continuar = document.createElement("button");
    continuar.className = "boton boton--oro continuar-puerta";
    continuar.dataset.accion = "ir";
    continuar.dataset.escena = "6";
    continuar.textContent = "Continuar la aventura";
    mensaje.insertAdjacentElement("afterend", continuar);
  }

  function responderHistoria(valor) {
    if (bloqueado) return;
    const mensaje = document.getElementById("mensajeHistoria");
    if (valor !== 24) {
      Sonidos.reproducir("casi");
      Progreso.sumar("4x6", "errores");
      mensaje.textContent = "Nubo: “Casi. Son 6 pajaritos en cada una de las 4 torres.”";
      return;
    }
    bloqueado = true;
    Sonidos.reproducir("acierto");
    Progreso.sumar("4x6", "aciertos");
    celebrarOperacion("4 × 6 = 24", "¡Encendiste las cuatro torres!", false);
    raiz.querySelector(".torres-pajaros").classList.add("torres-pajaros--felices");
    mensaje.className = "mensaje mensaje--bien";
    mensaje.innerHTML = "¡Los pajaritos encienden otra luz! <strong>4 × 6 = 24</strong> ✨";
    raiz.querySelector(".opciones").remove();
    document.getElementById("continuarHistoria").innerHTML = '<div class="fin-capitulo"><strong>Has recuperado el primer cristal.</strong><br>El sendero hacia las estrellas ya está abierto. 💎</div>';
  }

  raiz.addEventListener("click", function (evento) {
    const boton = evento.target.closest("[data-accion]");
    if (!boton) return;
    const accion = boton.dataset.accion;
    if (accion === "ir") { Sonidos.reproducir("viajar"); mostrar(Number(boton.dataset.escena)); }
    if (accion === "responder-visual") responderVisual(Number(boton.dataset.valor));
    if (accion === "responder-puerta") responderPuerta(Number(boton.dataset.valor));
    if (accion === "responder-historia") responderHistoria(Number(boton.dataset.valor));
    if (accion === "sonido") {
      const encendido = Sonidos.alternar();
      boton.textContent = encendido ? "🔊" : "🔇";
      boton.setAttribute("aria-label", encendido ? "Silenciar sonidos" : "Activar sonidos");
    }
    if (accion === "reiniciar") { Progreso.reiniciar(); mostrar(1); }
  });

  mostrar(Progreso.obtener().escenaActual);
})();
