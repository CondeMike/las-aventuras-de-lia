(function () {
  "use strict";
  const raiz = document.getElementById("juego");
  let bloqueado = false;
  function retoActual() { return Escenas.RETOS[Progreso.obtener().retoActual]; }
  function enfocarTitulo() { const t = raiz.querySelector("h1"); if (t) { t.tabIndex = -1; t.focus({ preventScroll: true }); } }
  function renderizar(escena) {
    bloqueado = false; const e = Progreso.obtener();
    if (escena === "inicio") raiz.innerHTML = Escenas.inicio(e);
    else if (escena === "mapa") raiz.innerHTML = Escenas.mapa(e);
    else if (escena === "reto" && retoActual()) raiz.innerHTML = Escenas.reto(retoActual(), e);
    else raiz.innerHTML = Escenas.final(e);
    window.scrollTo(0, 0); enfocarTitulo();
  }
  function celebrar(operacion, texto, cristal) {
    const capa = document.createElement("div"); capa.className = "celebracion-operacion" + (cristal ? " celebracion-operacion--cristal" : ""); capa.setAttribute("role", "status");
    capa.innerHTML = '<div class="rayos-logro" aria-hidden="true"></div>' + (cristal ? '<div class="cristal-magico" aria-hidden="true"><span class="gema">◆</span></div>' : "") + '<div class="ecuacion-impacto">' + operacion + '</div><div class="texto-logro">' + texto + '</div>';
    raiz.querySelector(".escena").appendChild(capa);
    window.setTimeout(function () { capa.classList.add("celebracion-operacion--sale"); }, cristal ? 1450 : 900);
    window.setTimeout(function () { capa.remove(); }, cristal ? 1850 : 1250);
  }
  function mostrarPista() { Progreso.pedirPista(); Sonidos.reproducir("ayuda"); renderizar("reto"); const m = document.getElementById("mensajeReto"); m.tabIndex = -1; m.focus({ preventScroll: true }); }
  function responder(valor) {
    if (bloqueado) return;
    const r = retoActual(); const correcto = r.grupos * 4;
    if (valor !== correcto) {
      Sonidos.reproducir("casi"); Progreso.registrarError(r.id); renderizar("reto");
      const m = document.getElementById("mensajeReto"); m.textContent = valor < correcto ? "Nubo: “Estás cerca. Parece que falta contar algún grupo.”" : "Nubo: “Estás cerca. Revisa cuántos grupos hay.”"; m.tabIndex = -1; m.focus({ preventScroll: true }); return;
    }
    bloqueado = true; Progreso.registrarAcierto(r.id); Sonidos.reproducir("acierto");
    const cristal = [1, 3, 6].includes(Progreso.obtener().retoActual);
    celebrar("4 × " + r.grupos + " = " + correcto, r.logro, cristal);
    raiz.querySelectorAll(".opcion, .boton--pista").forEach(function (b) { b.disabled = true; });
    document.getElementById("gruposReto").classList.add("brilla");
    const m = document.getElementById("mensajeReto"); m.className = "mensaje mensaje--bien"; m.innerHTML = "¡Buen conteo por grupos! <strong>4 × " + r.grupos + " = " + correcto + "</strong>";
    const b = document.createElement("button"); b.className = "boton boton--oro continuar-reto"; b.dataset.accion = "continuar"; b.disabled = true; b.textContent = cristal ? "Guardar el cristal" : "Seguir el sendero"; m.insertAdjacentElement("afterend", b);
    window.setTimeout(function () { bloqueado = false; b.disabled = false; b.focus({ preventScroll: true }); }, cristal ? 1850 : 1250);
  }
  function continuar() {
    const cristal = retoActual().cristal; Progreso.avanzarReto(); const siguiente = retoActual();
    if (!siguiente || siguiente.cristal !== cristal) { Progreso.concederCristal(cristal); Sonidos.reproducir("poder"); renderizar("mapa"); }
    else { Progreso.presentarReto(Progreso.obtener().retoActual); renderizar("reto"); }
  }
  function confirmarReinicio() {
    const d = document.createElement("div"); d.className = "dialogo-capa"; d.innerHTML = '<div class="dialogo" role="dialog" aria-modal="true" aria-labelledby="tituloDialogo"><h2 id="tituloDialogo">¿Empezar una aventura nueva?</h2><p>El recorrido actual volverá al comienzo.</p><button class="boton boton--oro" data-accion="reiniciar">Sí, empezar</button> <button class="boton boton--secundario" data-accion="cancelar-reinicio">Seguir jugando</button></div>'; raiz.querySelector(".escena").appendChild(d); d.querySelector("[data-accion='cancelar-reinicio']").focus();
  }
  raiz.addEventListener("click", function (ev) {
    const b = ev.target.closest("[data-accion]"); if (!b) return; const a = b.dataset.accion;
    if (a === "comenzar") { Progreso.iniciarAventura(); renderizar("mapa"); }
    else if (a === "abrir-reto") { Progreso.presentarReto(Progreso.obtener().retoActual); renderizar("reto"); }
    else if (a === "responder") responder(Number(b.dataset.valor));
    else if (a === "pista") mostrarPista(); else if (a === "continuar") continuar();
    else if (a === "ver-final") { Progreso.completar(); Sonidos.reproducir("poder"); renderizar("final"); }
    else if (a === "otra-vez") { Progreso.nuevaSesion(); Progreso.iniciarAventura(); renderizar("mapa"); }
    else if (a === "volver-inicio") { Progreso.guardarEscena("inicio"); renderizar("inicio"); }
    else if (a === "confirmar-reinicio") confirmarReinicio();
    else if (a === "cancelar-reinicio") { b.closest(".dialogo-capa").remove(); enfocarTitulo(); }
    else if (a === "reiniciar") { Progreso.nuevaSesion(); renderizar("inicio"); }
    else if (a === "sonido") { const activo = Sonidos.alternar(); Progreso.cambiarSonido(activo); b.textContent = activo ? "🔊" : "🔇"; b.setAttribute("aria-label", activo ? "Silenciar sonidos" : "Activar sonidos"); b.setAttribute("aria-pressed", activo); }
  });
  document.addEventListener("keydown", function (ev) { if (ev.key === "Escape") { const d = raiz.querySelector(".dialogo-capa"); if (d) { d.remove(); enfocarTitulo(); } } });
  Sonidos.establecer(Progreso.obtener().preferencias.sonido); renderizar(Progreso.obtener().escenaActual);
})();
