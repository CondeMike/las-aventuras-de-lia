(function () {
  "use strict";
  const RETOS = [
    { id: "4x2", cristal: 1, titulo: "El jardín de los primeros pasos", grupos: 2, objeto: "🌸", respuestas: [6, 8, 10], lugar: "jardines", logro: "¡Hiciste florecer el sendero!" },
    { id: "4x3", cristal: 1, titulo: "La puerta de piedra", grupos: 3, objeto: "♦", respuestas: [8, 12, 16], lugar: "cofres", logro: "¡Recuperaste el cristal del jardín!" },
    { id: "4x4", cristal: 2, titulo: "El bosque luminoso", grupos: 4, objeto: "✨", respuestas: [12, 16, 20], lugar: "árboles", logro: "¡El bosque vuelve a brillar!" },
    { id: "4x5", cristal: 2, titulo: "El río de las luciérnagas", grupos: 5, objeto: "●", respuestas: [16, 20, 24], lugar: "nenúfares", logro: "¡Recuperaste el cristal del bosque!" },
    { id: "4x6", cristal: 3, titulo: "Las torres de los pajaritos", grupos: 6, objeto: "🐦", respuestas: [20, 24, 28], lugar: "torres", logro: "¡Encendiste las torres!" },
    { id: "4x8", cristal: 3, titulo: "El observatorio de estrellas", grupos: 8, objeto: "★", respuestas: [28, 32, 36], lugar: "ventanas", logro: "¡Recuperaste el último cristal!" },
    { id: "4x10", cristal: 3, titulo: "La gran constelación", grupos: 10, objeto: "✦", respuestas: [36, 40, 44], lugar: "estrellas", logro: "¡Dominaste la magia del cuatro!" }
  ];
  function marco(contenido, clase, estado) {
    const activo = estado.preferencias.sonido;
    const cristales = [1, 2, 3].map(function (n) { return '<span class="' + (n <= estado.cristales ? "conseguido" : "") + '" aria-hidden="true">' + (n <= estado.cristales ? "◆" : "◇") + '</span>'; }).join("");
    return '<section class="escena ' + (clase || "") + '" aria-labelledby="tituloEscena"><div class="particulas" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></div>' +
      '<div class="barra"><span class="insignia">✨ Las Aventuras de Lía</span><span class="controles"><button class="control sonido" data-accion="sonido" aria-label="' + (activo ? "Silenciar sonidos" : "Activar sonidos") + '" aria-pressed="' + activo + '">' + (activo ? "🔊" : "🔇") + '</button><button class="control reiniciar" data-accion="confirmar-reinicio" aria-label="Empezar una aventura nueva">↻ <span>Reiniciar</span></button></span></div>' +
      '<div class="progreso-cristales" aria-label="' + estado.cristales + ' de 3 cristales recuperados">' + cristales + '</div>' + contenido + '</section>';
  }
  function inicio(estado) {
    const continua = estado.retoActual > 0 || estado.cristales > 0;
    return marco('<h1 id="tituloEscena" class="titulo">Las Aventuras de Lía</h1><p class="subtitulo">El misterio de las cuatro torres</p>' +
      '<div class="personajes" aria-label="Lía y Nubo"><div class="personaje"><img class="lia" src="assets/personajes/lia-v4.png" alt="Lía, joven exploradora"><span>Lía</span></div><div class="personaje"><img class="nubo" src="assets/personajes/nubo-v2.png" alt="Nubo, zorro dragón amistoso"><span>Nubo</span></div></div>' +
      '<div class="pergamino"><strong>¡Lía!</strong> Las torres necesitan tres cristales. Los encontraremos repitiendo el número 4: una vez, dos veces, tres veces…</div><button class="boton boton--oro" data-accion="comenzar">' + (continua ? "Continuar aventura" : "¡Comenzar aventura!") + '</button>', "escena--inicio", estado);
  }
  function mapa(estado) {
    const siguiente = RETOS[estado.retoActual];
    return marco('<h1 id="tituloEscena" class="titulo">Mapa del Reino Cuadrado</h1><div class="pergamino pergamino--mapa"><strong>' + (estado.cristales === 0 ? "La misión comienza" : estado.cristales === 3 ? "Los tres cristales están listos" : "¡Ya recuperaste " + estado.cristales + " de 3 cristales!") + '</strong><br>' + (siguiente ? "Sigue el sendero y descubre otra forma de pensar con el 4." : "Es hora de devolver la luz al reino.") + '</div>' +
      '<div class="mapa-ruta"><button class="torre torre--activa" data-accion="' + (siguiente ? "abrir-reto" : "ver-final") + '" aria-label="' + (siguiente ? "Ir al siguiente desafío" : "Ver celebración final") + '"><span class="portal">✦</span><small>' + (siguiente ? "Siguiente<br>desafío" : "Celebrar<br>la aventura") + '</small></button></div><div class="placa-mundo">Familia del 4 <small>' + estado.retoActual + ' de ' + RETOS.length + ' retos</small></div>', "escena--mapa", estado);
  }
  function gruposHTML(r, nivel) {
    return '<div class="grupos grupos--aprendizaje nivel-ayuda-' + nivel + '" id="gruposReto" aria-label="' + r.grupos + ' grupos de cuatro">' + Array.from({ length: r.grupos }, function (_, i) { return '<div class="grupo" style="--orden:' + i + '"><span class="numero-grupo" aria-hidden="true">' + (i + 1) + '</span><span class="elementos" aria-hidden="true">' + r.objeto.repeat(4) + '</span></div>'; }).join("") + '</div>';
  }
  function reto(r, estado) {
    const nivel = estado.nivelAyuda; const suma = Array.from({ length: r.grupos }, function () { return "4"; }).join(" + ");
    const pista = nivel === 0 ? "Nubo: “Mira los grupos y piensa con calma.”" : nivel === 1 ? "Nubo: “Cuenta de cuatro en cuatro siguiendo las luces.”" : "Nubo: “Completa la suma y elige el total.”";
    const conteo = Array.from({ length: r.grupos }, function (_, i) { return '<span>' + ((i + 1) * 4) + '</span>'; }).join('<i aria-hidden="true">→</i>');
    return marco('<h1 id="tituloEscena" class="titulo titulo--reto">' + r.titulo + '</h1><div class="operacion-guia"><strong>El 4, ' + r.grupos + ' veces</strong><span>4 × ' + r.grupos + '</span></div><div class="pergamino pergamino--reto">En cada uno de los <strong>' + r.grupos + ' ' + r.lugar + '</strong> hay un grupo de 4 elementos.<br>Tenemos el 4 repetido ' + r.grupos + ' veces. ¿Cuántos elementos hay en total?</div>' + gruposHTML(r, nivel) + (nivel > 0 ? '<div class="conteo-guiado" aria-label="Conteo de cuatro en cuatro">' + conteo + '</div>' : '') + (nivel === 2 ? '<div class="suma-repetida">' + suma + ' = ?</div>' : '') +
      '<div class="opciones" role="group" aria-label="Elige una respuesta">' + r.respuestas.map(function (v) { return '<button class="opcion" data-accion="responder" data-valor="' + v + '">' + v + '</button>'; }).join("") + '</div><div class="mensaje" id="mensajeReto" role="status" aria-live="polite">' + pista + '</div>' + (nivel < 2 ? '<button class="boton boton--pista" data-accion="pista">💡 Quiero una pista</button>' : ''), "escena--reto", estado);
  }
  function final(estado) {
    const s = estado.sesion;
    return marco('<h1 id="tituloEscena" class="titulo">¡El reino vuelve a brillar!</h1><div class="final-cristales" aria-hidden="true">◆ ◆ ◆</div><img class="nubo nubo--final" src="assets/personajes/nubo-v2.png" alt="Nubo celebrando"><div class="pergamino"><strong>Completaste la aventura repitiendo el 4 distintas cantidades de veces.</strong><br>Observaste, contaste y volviste a intentarlo cuando fue necesario.</div>' +
      '<dl class="resumen"><div><dt>Retos superados</dt><dd>' + s.aciertos + '</dd></div><div><dt>Al primer intento</dt><dd>' + s.aciertosPrimerIntento + '</dd></div><div><dt>Pistas usadas</dt><dd>' + s.ayudasUsadas + '</dd></div></dl><button class="boton boton--oro" data-accion="otra-vez">Jugar otra vez</button> <button class="boton boton--secundario" data-accion="volver-inicio">Continuar después</button>', "escena--final", estado);
  }
  window.Escenas = { RETOS: RETOS, inicio: inicio, mapa: mapa, reto: reto, final: final };
})();
